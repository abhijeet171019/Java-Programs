package com.training;

import java.util.Scanner;

class programming
    {
        public static void main(String args[])
        {
            Scanner pro = new Scanner (System.in);
            System.out.println("If you love any programming language type that or else press enter");
            String new_String = pro.nextLine();
            if(new_String.length()>1)
                System.out.println( "I love " +new_String);
            else
                System.out.println(" I love programming languages");
        }
    }

